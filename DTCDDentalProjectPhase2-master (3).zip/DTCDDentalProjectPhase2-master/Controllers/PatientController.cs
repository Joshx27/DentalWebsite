﻿// Importing the necessary namespaces
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTCDDentalProject.Models;

// Declaring a controller named "PatientController" that inherits from the "Controller" class
namespace DTCDDentalProject.Controllers
{
    public class PatientController : Controller
    {
        // Creating an instance of the "DTCDentalContext" class
        private DTCDentalContext context { get; set; }

        // Creating a constructor to initialize the instance of the "DTCDentalContext" class
        public PatientController(DTCDentalContext ctx) => context = ctx;

        // Defining an action method "Index" that redirects to the "List" action method
        public RedirectToActionResult Index() => RedirectToAction("List");

        // Defining an action method "List" that returns a view with a list of all patients
        [Route("[controller]s")]
        public ViewResult List()
        {
            // Retrieving all patients from the database and storing them in a variable named "patients"
            var patients = context.Patients.ToList();
            // Returning a view with the list of patients
            return View(patients);
        }

        // Defining an HTTP GET action method "Add" that returns a view with a form to add a new patient
        [HttpGet]
        public ViewResult Add()
        {
            // Setting a view bag property to "Add"
            ViewBag.Action = "Add";
            // Returning a view with an empty patient object
            return View("AddEdit", new Patient());
        }

        // Defining an HTTP GET action method "Edit" that returns a view with a form to edit an existing patient
        [HttpGet]
        public ViewResult Edit(int id)
        {
            // Setting a view bag property to "Edit"
            ViewBag.Action = "Edit";
            // Retrieving the patient with the specified ID from the database and storing it in a variable named "patient"
            var patient = context.Patients.Find(id);
            // Returning a view with the patient object
            return View("AddEdit", patient);
        }

        // Defining an HTTP POST action method "Save" that saves a new or updated patient to the database
        [HttpPost]
        public IActionResult Save(Patient patient)
        {
            // Initializing a variable named "message" to an empty string
            string message = string.Empty;

            // Checking if the model state is valid
            if (ModelState.IsValid)
            {
                // Checking if another patient with the same email address already exists in the database
                var existingPatient = context.Patients.FirstOrDefault(p => p.PatientEmail == patient.PatientEmail && p.PatientID != patient.PatientID);
                if (existingPatient != null)
                {
                    // Adding a model error for the email field and returning the view with the patient object
                    ModelState.AddModelError("Email", "This email address is already used by another patient.");
                    ViewBag.Action = (patient.PatientID == 0) ? "Add" : "Edit";
                    return View("AddEdit", patient);
                }

                // Checking if the patient ID is 0, indicating a new patient
                if (patient.PatientID == 0)
                {
                    // Adding the new patient to the database
                    context.Patients.Add(patient);
                    // Setting the message to a string indicating the patient was added
                    message = patient.PatientFullName + " was added.";
                }
                else
                {
                    // Updating the existing patient in the database
                    context.Patients.Update(patient);
                    // Setting the message to a string indicating the patient was updated
                    message = patient.PatientFullName + " was updated.";
                }
                // Saving the changes to the database
                context.SaveChanges(); // Save changes to the database
                TempData["message"] = message; // Store a success message in TempData to be displayed on the next request
                return RedirectToAction("List"); // Redirect to the List action method
            }
            else
            {
                if (patient.PatientID == 0)
                {
                    ViewBag.Action = "Add"; // Set ViewBag.Action to "Add" if the patient being saved is a new patient
                }
                else
                {
                    ViewBag.Action = "Edit"; // Set ViewBag.Action to "Edit" if the patient being saved is an existing patient
                }
                return View("AddEdit", patient); // Return the AddEdit view with the patient data
            }
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var product = context.Patients.Find(id); // Find the patient with the specified ID
            return View(product); // Return the Delete view with the patient data
        }

        [HttpPost]
        public RedirectToActionResult Delete(Patient patient)
        {
            context.Patients.Remove(patient); // Remove the patient from the context
            context.SaveChanges(); // Save changes to the database
            TempData["message"] = patient.PatientFullName + " was deleted."; // Store a success message in TempData to be displayed on the next request
            return RedirectToAction("List"); // Redirect to the List action method
        }
    }
}