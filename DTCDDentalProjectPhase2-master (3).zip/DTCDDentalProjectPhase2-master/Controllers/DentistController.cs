﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTCDDentalProject.Models;

namespace DTCDDentalProject.Controllers
{
    public class DentistController : Controller
    {
        private DTCDentalContext context { get; set; }
        public DentistController(DTCDentalContext ctx) => context = ctx;

        public RedirectToActionResult Index() => RedirectToAction("List");

        [Route("[controller]s")]
        public ViewResult List()
        {
            var dentists = context.Dentists.ToList();
            return View(dentists);
        }

        [HttpGet]
        public ViewResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new Dentist());
        }

        [HttpGet]
        public ViewResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var dentist = context.Dentists.Find(id);
            return View("AddEdit", dentist);
        }

        [HttpPost]
        public IActionResult Save(Dentist dentist)
        {
            string message = string.Empty;
            if (ModelState.IsValid)
            {
                if (dentist.DentistID == 0)
                {
                    context.Dentists.Add(dentist);
                    message = dentist.DentistFirstName + " was added.";
                }
                else
                {
                    context.Dentists.Update(dentist);
                    message = dentist.DentistFirstName + " was updated.";
                }
                context.SaveChanges();
                TempData["message"] = message;
                return RedirectToAction("List");
            }
            else
            {
                if (dentist.DentistID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                return View("AddEdit", dentist);
            }
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var dentist = context.Dentists.Find(id);
            return View(dentist);
        }

        [HttpPost]
        public RedirectToActionResult Delete(Dentist dentist)
        {
            context.Dentists.Remove(dentist);
            context.SaveChanges();
            TempData["message"] = dentist.DentistFirstName + " was deleted.";
            return RedirectToAction("List");
        }
    }
}
