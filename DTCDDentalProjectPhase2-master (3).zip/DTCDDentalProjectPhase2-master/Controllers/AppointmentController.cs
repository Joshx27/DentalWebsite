﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTCDDentalProject.Models;
using System.Globalization;
using Microsoft.EntityFrameworkCore;

namespace DTCDDentalProject.Controllers
{
    public class AppointmentController : Controller
    {
        private DTCDentalContext context { get; set; }

        // Constructor injection of the context for the controller
        public AppointmentController(DTCDentalContext ctx) => context = ctx;

        // Action method to redirect to the List action
        public RedirectToActionResult Index() => RedirectToAction("List");

        // Action method to display the list of appointments
        [Route("[controller]s")]
        public ViewResult List()
        {
            var appointments = context.Appointments.Include(a => a.Dentist).Include(a => a.Patient).ToList();
            return View(appointments);
        }

        public void StoreDataInViewBag(string action)
        {
            ViewBag.Action = action;

            ViewBag.Dentists = context.Dentists
                .OrderBy(d => d.DentistFirstName)
                .ToList();

            ViewBag.Patients = context.Patients
                .OrderBy(p => p.PatientFirstName)
                .ToList();

            ViewBag.Types = context.AppointmentTypes
                .OrderBy(t => t.AppointmentTypeID)
                .ToList();
        }

        // Action method to display the form for adding a new appointment
        [HttpGet]
        public ViewResult Add()
        {
            StoreDataInViewBag("Add"); // Set the value of the ViewBag.Action property to "Add"
            return View("AddEdit", new Appointment()); // Return the AddEdit view with an empty Appointment object
        }

        // Action method to display the form for editing an existing appointment
        [HttpGet]
        public ViewResult Edit(int id)
        {
            StoreDataInViewBag("Edit"); // Set the value of the ViewBag.Action property to "Edit"
            var appointment = context.Appointments.Find(id); // Get the appointment object from the context
            return View("AddEdit", appointment); // Return the AddEdit view with the selected Appointment object
        }

        // Action method to save the appointment data from the AddEdit form
        [HttpPost]
        public IActionResult Save(Appointment appointment)
        {
            string message = string.Empty;
            if (ModelState.IsValid) // Check if the model state is valid
            {
                if (appointment.AppointmentID == 0) // Check if the appointment ID is 0 (i.e., new appointment)
                {
                    context.Appointments.Add(appointment); // Add the new appointment to the context
                    message = appointment.AppointmentID + " was added."; // Set the message to indicate that the appointment was added
                }
                else // Otherwise, the appointment ID is not 0 (i.e., existing appointment)
                {
                    context.Appointments.Update(appointment); // Update the appointment in the context
                    message = appointment.AppointmentID + " was updated."; // Set the message to indicate that the appointment was updated
                }
                context.SaveChanges(); // Save changes to the context
                TempData["message"] = message; // Set the message in TempData
                return RedirectToAction("List"); // Redirect to the List action
            }
            else // Otherwise, the model state is not valid
            {
                if (appointment.AppointmentID == 0) // Check if the appointment ID is 0 (i.e., new appointment)
                {
                    StoreDataInViewBag("Add"); // Set the value of the ViewBag.Action property to "Add"
                }
                else // Otherwise, the appointment ID is not 0 (i.e., existing appointment)
                {
                    StoreDataInViewBag("Edit"); // Set the value of the ViewBag.Action property to "Edit"
                }
                return View("AddEdit", appointment); // Return the AddEdit view with the Appointment object
            }
        }

        // Action method to display the form for deleting an appointment
        [HttpGet]
        public ViewResult Delete(int id)
        {
            var appointment = context.Appointments.Find(id); // Get the appointment object from the context
            return View(appointment); // Return the Delete view with the selected Appointment object
        }

        // Action method to delete the appointment data
        [HttpPost]
        public RedirectToActionResult Delete(Appointment appointment)
        {
            context.Appointments.Remove(appointment);
            context.SaveChanges();
            TempData["message"] = appointment.AppointmentID + " was deleted.";
            return RedirectToAction("List");
        }

        
    }
}