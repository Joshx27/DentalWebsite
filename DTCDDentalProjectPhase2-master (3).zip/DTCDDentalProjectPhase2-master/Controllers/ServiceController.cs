﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTCDDentalProject.Models;

namespace DTCDDentalProject.Controllers
{
    public class ServiceController : Controller
    {
        private DTCDentalContext context { get; set; }
        public ServiceController(DTCDentalContext ctx) => context = ctx;

        public RedirectToActionResult Index() => RedirectToAction("List");

        [Route("[controller]s")]
        public ViewResult List()
        {
            var services = context.Services.ToList();
            return View(services);
        }

        [HttpGet]
        public ViewResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new Service());
        }

        [HttpGet]
        public ViewResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var service = context.Services.Find(id);
            return View("AddEdit", service);
        }

        [HttpPost]
        public IActionResult Save(Service service)
        {
            string message = string.Empty;
            if (ModelState.IsValid)
            {
                if (service.ServiceID == 0)
                {
                    context.Services.Add(service);
                    message = service.ServiceDescription + " was added.";
                }
                else
                {
                    context.Services.Update(service);
                    message = service.ServiceDescription + " was updated.";
                }
                context.SaveChanges();
                TempData["message"] = message;
                return RedirectToAction("List");
            }
            else
            {
                if (service.ServiceID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                return View("AddEdit", service);
            }
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var service = context.Services.Find(id);
            return View(service);
        }

        [HttpPost]
        public RedirectToActionResult Delete(Service service)
        {
            context.Services.Remove(service);
            context.SaveChanges();
            TempData["message"] = service.ServiceDescription + " was deleted.";
            return RedirectToAction("List");
        }
    }
}
