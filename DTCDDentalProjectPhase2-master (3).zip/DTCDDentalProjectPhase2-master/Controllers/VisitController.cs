﻿// This controller is responsible for managing visits made by patients to the dentist. 

using DTCDDentalProject.Migrations;
using DTCDDentalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

namespace DTCDDentalProject.Controllers
{
    public class VisitController : Controller
    {
        public DTCDentalContext _context { get; set; } // The database context
        public VisitView _visit; // The VisitView object which stores the selected services in the visit cart

        // Redirects to the "List" action.
        public RedirectToActionResult Index() => RedirectToAction("List");

        // Displays a list of available services.
        [Route("[controller]s")]
        public ViewResult List()
        {
            var services = _context.Services.ToList();
            return View(services);
        }

        // Constructor that injects the database context and the VisitView object.
        public VisitController(DTCDentalContext context, VisitView visit)
        {
            _context = context;
            _visit = visit;
        }

        // Displays the visit cart and allows the user to add services to the cart.
        [HttpGet]
        public IActionResult VisitCart(int id)
        {
            int serviceID = id;
            var selectedService = _context.Services.FirstOrDefault(s => s.ServiceID == serviceID);

            if (selectedService != null)
            {
                // Checks if the service is already in the cart, and adds it if it is not.
                if (_visit.VisitCart.Count > 0 && _visit.VisitCart.Any(s => s.ServiceID == selectedService.ServiceID))
                {
                    TempData["Message"] = "This service is already in your visit cart.";
                }
                else
                {
                    _visit.VisitCart.Add(selectedService);
                }
            }

            return View("VisitCart", _visit.VisitCart);
        }

        // Removes a service from the visit cart.
        public IActionResult RemoveFromCart(int id)
        {
            int serviceID = id;
            var selectedService = _visit.VisitCart.SingleOrDefault(s => s.ServiceID == serviceID);

            if (selectedService != null)
            {
                _visit.VisitCart.Remove(selectedService);
            }

            return RedirectToAction("VisitCart", 0);
        }

        // Clears the visit cart.
        public IActionResult ClearCart()
        {
            _visit.VisitCart.Clear();
            return RedirectToAction("VisitCart", 0);
        }

        // Displays the "RecordVisit" view, which allows the user to select services for a visit.
        [HttpGet]
        public IActionResult RecordVisit()
        {
            return View(_context.Services.ToList());
        }

        // Displays the "FinalizeVisit" view, which allows the user to select a patient and a dentist 
        // and view the selected services and the total cost of the visit.
        public IActionResult FinalizeVisit()
        {
            var visitCart = _visit.VisitCart.ToList();
            var totalCost = visitCart.Sum(service => service.ServiceCost);

            var dentists = _context.Dentists.ToList();
            ViewBag.Dentists = dentists;

            var patients = _context.Patients.ToList();
            ViewBag.Patients = patients;

            var visitView = new VisitView
            {
                Patients = patients,
                Dentists = dentists,
                VisitCart = visitCart,
                TotalCost = totalCost
            };

            return View(visitView);
        }

        [HttpPost]

        // Saves the visit to the database
        public IActionResult Save(Visit __visit, Dentist dentist, Patient patient)
        {
            int VisitID = __visit.VisitID;
            int DentistID = dentist.DentistID;
            int PatientID = patient.PatientID;

            // create a new Visit object with the selected Dentist and Patient IDs, and the current date
            var visit = new Visit
            {
                VisitID = VisitID,
                DentistID = DentistID,
                PatientID = PatientID,
                VisitDate = DateTime.Now
            };

            // add the Visit and CompletedServices to the database
            /*if (dentist != null && patient != null)
            {
                _context.Visits.Add(visit);
                _context.SaveChanges();

                foreach (var service in _visit.VisitCart)
                {
                    var visitService = new CompletedService
                    {
                        VisitID = visit.VisitID,
                        ServiceID = service.ServiceID
                    };

                    _context.CompletedServices.Add(visitService);
                    _context.SaveChanges();

                }

                _context.SaveChanges();
            }*/

            // display the Confirmation view with the Visit object passed as the model
            return View("Confirmation", visit);
        }
    }
}