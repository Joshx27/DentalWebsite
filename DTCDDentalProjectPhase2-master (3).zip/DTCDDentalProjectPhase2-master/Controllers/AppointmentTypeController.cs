﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTCDDentalProject.Models;

namespace DTCDDentalProject.Controllers
{
    public class AppointmentTypeController : Controller
    {
        private DTCDentalContext context { get; set; }
        public AppointmentTypeController(DTCDentalContext ctx) => context = ctx;

        public RedirectToActionResult Index() => RedirectToAction("List");

        [Route("[controller]s")]
        public ViewResult List()
        {
            var appointmentType = context.AppointmentTypes.ToList();
            return View(appointmentType);
        }

        [HttpGet]
        public ViewResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new AppointmentType());
        }

        [HttpGet]
        public ViewResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var appointmentType = context.AppointmentTypes.Find(id);
            return View("AddEdit", appointmentType);
        }

        [HttpPost]
        public IActionResult Save(AppointmentType appointmentType)
        {
            string message = string.Empty;
            if (ModelState.IsValid)
            {
                if (appointmentType.AppointmentTypeID == 0)
                {
                    context.AppointmentTypes.Add(appointmentType);
                    message = appointmentType.AppointmentName + " was added.";
                }
                else
                {
                    context.AppointmentTypes.Update(appointmentType);
                    message = appointmentType.AppointmentName + " was updated.";
                }
                context.SaveChanges();
                TempData["message"] = message;
                return RedirectToAction("List");
            }
            else
            {
                if (appointmentType.AppointmentTypeID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                return View("AddEdit", appointmentType);
            }
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var appointmentType = context.AppointmentTypes.Find(id);
            return View(appointmentType);
        }

        [HttpPost]
        public RedirectToActionResult Delete(AppointmentType appointmentType)
        {
            context.AppointmentTypes.Remove(appointmentType);
            context.SaveChanges();
            TempData["message"] = appointmentType.AppointmentName + " was deleted.";
            return RedirectToAction("List");
        }
    }
}
