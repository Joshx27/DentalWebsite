﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class dentist : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Dentists",
                columns: new[] { "DentistID", "DentistFirstName", "DentistLastName", "HireDate" },
                values: new object[,]
                {
                    { 1, "Ariana", "Grande", new DateTime(2023, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, "Emma", "Watson", new DateTime(2022, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, "Daniel", "Radcliffe", new DateTime(2022, 5, 12, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, "Jennifer", "Lawrence", new DateTime(2022, 10, 5, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, "Tom", "Hiddleston", new DateTime(2023, 1, 15, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 5);
        }
    }
}
