﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppointmentTypes",
                columns: table => new
                {
                    TypeID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AppointmentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Duration = table.Column<TimeSpan>(type: "time", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppointmentTypes", x => x.TypeID);
                });

            migrationBuilder.CreateTable(
                name: "CompletedServices",
                columns: table => new
                {
                    CompletedServiceID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ServiceID = table.Column<int>(type: "int", nullable: false),
                    VisitID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CompletedServices", x => x.CompletedServiceID);
                });

            migrationBuilder.CreateTable(
                name: "Dentists",
                columns: table => new
                {
                    DentistID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DentistFirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DentistLastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dentists", x => x.DentistID);
                });

            migrationBuilder.CreateTable(
                name: "Patients",
                columns: table => new
                {
                    PatientID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PatientFirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientLastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientStreetAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientState = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientZip = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientPhone = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PatientEmail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PatientSSN = table.Column<long>(type: "bigint", nullable: false),
                    PatientDOB = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PatientMinor = table.Column<bool>(type: "bit", nullable: false),
                    PatientHOHID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Patients", x => x.PatientID);
                    table.ForeignKey(
                        name: "FK_Patients_Patients_PatientHOHID",
                        column: x => x.PatientHOHID,
                        principalTable: "Patients",
                        principalColumn: "PatientID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Services",
                columns: table => new
                {
                    ServiceID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ServiceDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ServiceCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Services", x => x.ServiceID);
                });

            migrationBuilder.CreateTable(
                name: "Appointments",
                columns: table => new
                {
                    AppointmentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AppointmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DentistID = table.Column<int>(type: "int", nullable: false),
                    PatientID = table.Column<int>(type: "int", nullable: false),
                    TypeID = table.Column<int>(type: "int", nullable: false),
                    AppointmentTypeTypeID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Appointments", x => x.AppointmentID);
                    table.ForeignKey(
                        name: "FK_Appointments_AppointmentTypes_AppointmentTypeTypeID",
                        column: x => x.AppointmentTypeTypeID,
                        principalTable: "AppointmentTypes",
                        principalColumn: "TypeID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Appointments_Dentists_DentistID",
                        column: x => x.DentistID,
                        principalTable: "Dentists",
                        principalColumn: "DentistID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Appointments_Patients_PatientID",
                        column: x => x.PatientID,
                        principalTable: "Patients",
                        principalColumn: "PatientID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Visits",
                columns: table => new
                {
                    VisitID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DentistID = table.Column<int>(type: "int", nullable: false),
                    PatientID = table.Column<int>(type: "int", nullable: false),
                    VisitDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Visits", x => x.VisitID);
                    table.ForeignKey(
                        name: "FK_Visits_Dentists_DentistID",
                        column: x => x.DentistID,
                        principalTable: "Dentists",
                        principalColumn: "DentistID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Visits_Patients_PatientID",
                        column: x => x.PatientID,
                        principalTable: "Patients",
                        principalColumn: "PatientID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Patients",
                columns: new[] { "PatientID", "PatientCity", "PatientDOB", "PatientEmail", "PatientFirstName", "PatientHOHID", "PatientLastName", "PatientMinor", "PatientPhone", "PatientSSN", "PatientState", "PatientStreetAddress", "PatientZip" },
                values: new object[,]
                {
                    { 1, "Englewood", new DateTime(2001, 10, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Daniel", 1, "Ortiz", false, "713-732-8964", 217569823L, "CO", "Way Over Dr.", "80113" },
                    { 2, "Englewood", new DateTime(1985, 6, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Emily", 2, "Garcia", false, "303-555-1212", 478681095L, "CO", "4525 S Broadway", "80113" },
                    { 3, "Denver", new DateTime(1990, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Ryan", 3, "Lee", false, "720-555-1212", 623945278L, "CO", "4650 S. Yosemite St.", "80237" },
                    { 4, "Englewood", new DateTime(1978, 11, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Avery", 4, "Nguyen", false, "303-555-1212", 385317906L, "CO", "3595 S Pearl St", "80113" },
                    { 6, "Englewood", new DateTime(1996, 8, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Blake", 6, "Hernandez", false, "303-555-1212", 242693150L, "CO", "88 Inverness Cir E", "80112" },
                    { 7, "Englewood", new DateTime(1975, 4, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Isabella", 7, "Martinez", false, "303-555-1212", 583124286L, "CO", "3500 S. Logan St.", "80113" },
                    { 11, "Englewood", new DateTime(1999, 11, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Aria", 11, "Sanchez", false, "303-555-1212", 806629351L, "CO", "10125 E Peakview Ave", "80111" },
                    { 12, "Denver", new DateTime(1988, 6, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Oliver", 12, "Flores", false, "303-555-1212", 575371032L, "CO", "6500 E Hampden Ave", "80224" },
                    { 13, "Aurora", new DateTime(1991, 9, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Emma", 13, "Garcia", false, "720-555-1212", 989816025L, "CO", "14200 E Alameda Ave", "80012" },
                    { 14, "Aurora", new DateTime(1979, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Noah", 14, "Hernandez", false, "303-555-1212", 431247769L, "CO", "2990 S Peoria St", "80014" },
                    { 15, "Denver", new DateTime(1963, 8, 7, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Avery", 15, "Lopez", false, "720-555-1212", 703503241L, "CO", "7150 Leetsdale Dr", "80224" },
                    { 5, "Greenwood Village", new DateTime(2006, 1, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Olivia", 3, "Wilson", true, "720-555-1212", 719468213L, "CO", "7315 E Belleview Ave", "80111" },
                    { 8, "Englewood", new DateTime(1982, 9, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Mason", 7, "Gonzalez", false, "720-555-1212", 934772608L, "CO", "3475 S University Blvd", "80113" },
                    { 9, "Greenwood Village", new DateTime(2011, 2, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Sophia", 7, "Rodriguez", true, "303-555-1212", 156538907L, "CO", "7447 E Berry Ave", "80111" },
                    { 10, "Centennial", new DateTime(2004, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Aiden", 7, "Chavez", true, "720-555-1212", 341284689L, "CO", "7395 E Peakview Ave", "80111" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Appointments_AppointmentTypeTypeID",
                table: "Appointments",
                column: "AppointmentTypeTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_Appointments_DentistID",
                table: "Appointments",
                column: "DentistID");

            migrationBuilder.CreateIndex(
                name: "IX_Appointments_PatientID",
                table: "Appointments",
                column: "PatientID");

            migrationBuilder.CreateIndex(
                name: "IX_Patients_PatientHOHID",
                table: "Patients",
                column: "PatientHOHID");

            migrationBuilder.CreateIndex(
                name: "IX_Visits_DentistID",
                table: "Visits",
                column: "DentistID");

            migrationBuilder.CreateIndex(
                name: "IX_Visits_PatientID",
                table: "Visits",
                column: "PatientID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Appointments");

            migrationBuilder.DropTable(
                name: "CompletedServices");

            migrationBuilder.DropTable(
                name: "Services");

            migrationBuilder.DropTable(
                name: "Visits");

            migrationBuilder.DropTable(
                name: "AppointmentTypes");

            migrationBuilder.DropTable(
                name: "Dentists");

            migrationBuilder.DropTable(
                name: "Patients");
        }
    }
}
