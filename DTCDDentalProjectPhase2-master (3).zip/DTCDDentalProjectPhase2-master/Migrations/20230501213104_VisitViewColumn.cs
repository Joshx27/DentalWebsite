﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class VisitViewColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Services_Visits_VisitID",
                table: "Services");

            migrationBuilder.RenameColumn(
                name: "VisitID",
                table: "Services",
                newName: "VisitViewVisitID1");

            migrationBuilder.RenameIndex(
                name: "IX_Services_VisitID",
                table: "Services",
                newName: "IX_Services_VisitViewVisitID1");

            migrationBuilder.AddColumn<int>(
                name: "VisitViewVisitID",
                table: "Services",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "VisitView",
                columns: table => new
                {
                    VisitID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DentistID = table.Column<int>(type: "int", nullable: false),
                    PatientID = table.Column<int>(type: "int", nullable: false),
                    TotalCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitView", x => x.VisitID);
                });

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 1,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 2,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 3,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 4,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 5,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 6,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 7,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 8,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 9,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 10,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 11,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 12,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 13,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 14,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 15,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_Services_VisitViewVisitID",
                table: "Services",
                column: "VisitViewVisitID");

            migrationBuilder.AddForeignKey(
                name: "FK_Services_VisitView_VisitViewVisitID",
                table: "Services",
                column: "VisitViewVisitID",
                principalTable: "VisitView",
                principalColumn: "VisitID");

            migrationBuilder.AddForeignKey(
                name: "FK_Services_VisitView_VisitViewVisitID1",
                table: "Services",
                column: "VisitViewVisitID1",
                principalTable: "VisitView",
                principalColumn: "VisitID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Services_VisitView_VisitViewVisitID",
                table: "Services");

            migrationBuilder.DropForeignKey(
                name: "FK_Services_VisitView_VisitViewVisitID1",
                table: "Services");

            migrationBuilder.DropTable(
                name: "VisitView");

            migrationBuilder.DropIndex(
                name: "IX_Services_VisitViewVisitID",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "VisitViewVisitID",
                table: "Services");

            migrationBuilder.RenameColumn(
                name: "VisitViewVisitID1",
                table: "Services",
                newName: "VisitID");

            migrationBuilder.RenameIndex(
                name: "IX_Services_VisitViewVisitID1",
                table: "Services",
                newName: "IX_Services_VisitID");

            migrationBuilder.AddForeignKey(
                name: "FK_Services_Visits_VisitID",
                table: "Services",
                column: "VisitID",
                principalTable: "Visits",
                principalColumn: "VisitID");
        }
    }
}
