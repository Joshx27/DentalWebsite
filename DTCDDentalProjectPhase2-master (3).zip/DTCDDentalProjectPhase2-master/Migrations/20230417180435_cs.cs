﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class cs : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_CompletedServices",
                table: "CompletedServices");

            migrationBuilder.DropColumn(
                name: "CompletedServiceID",
                table: "CompletedServices");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CompletedServices",
                table: "CompletedServices",
                columns: new[] { "ServiceID", "VisitID" });

            migrationBuilder.InsertData(
                table: "CompletedServices",
                columns: new[] { "ServiceID", "VisitID" },
                values: new object[,]
                {
                    { 1, 1 },
                    { 2, 1 },
                    { 2, 11 },
                    { 3, 1 },
                    { 3, 11 },
                    { 4, 1 },
                    { 4, 11 },
                    { 5, 1 },
                    { 5, 11 },
                    { 6, 7 },
                    { 7, 1 },
                    { 7, 11 },
                    { 8, 1 },
                    { 8, 11 },
                    { 9, 1 },
                    { 9, 11 },
                    { 10, 1 },
                    { 10, 11 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_CompletedServices",
                table: "CompletedServices");

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 1, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 2, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 2, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 3, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 3, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 4, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 4, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 5, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 5, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 6, 7 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 7, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 7, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 8, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 8, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 9, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 9, 11 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 10, 1 });

            migrationBuilder.DeleteData(
                table: "CompletedServices",
                keyColumns: new[] { "ServiceID", "VisitID" },
                keyValues: new object[] { 10, 11 });

            migrationBuilder.AddColumn<int>(
                name: "CompletedServiceID",
                table: "CompletedServices",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CompletedServices",
                table: "CompletedServices",
                column: "CompletedServiceID");
        }
    }
}
