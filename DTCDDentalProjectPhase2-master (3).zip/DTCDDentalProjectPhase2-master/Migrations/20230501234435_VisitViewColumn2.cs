﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class VisitViewColumn2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Services_VisitView_VisitViewVisitID1",
                table: "Services");

            migrationBuilder.DropIndex(
                name: "IX_Services_VisitViewVisitID1",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "VisitViewVisitID1",
                table: "Services");

            migrationBuilder.AddColumn<int>(
                name: "VisitViewVisitID",
                table: "Patients",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "VisitViewVisitID",
                table: "Dentists",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 1,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 2,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 3,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 4,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Dentists",
                keyColumn: "DentistID",
                keyValue: 5,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 1,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 2,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 3,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 4,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 5,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 6,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 7,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 8,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 9,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 10,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 11,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 12,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 13,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 14,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Patients",
                keyColumn: "PatientID",
                keyValue: 15,
                column: "VisitViewVisitID",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_Patients_VisitViewVisitID",
                table: "Patients",
                column: "VisitViewVisitID");

            migrationBuilder.CreateIndex(
                name: "IX_Dentists_VisitViewVisitID",
                table: "Dentists",
                column: "VisitViewVisitID");

            migrationBuilder.AddForeignKey(
                name: "FK_Dentists_VisitView_VisitViewVisitID",
                table: "Dentists",
                column: "VisitViewVisitID",
                principalTable: "VisitView",
                principalColumn: "VisitID");

            migrationBuilder.AddForeignKey(
                name: "FK_Patients_VisitView_VisitViewVisitID",
                table: "Patients",
                column: "VisitViewVisitID",
                principalTable: "VisitView",
                principalColumn: "VisitID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Dentists_VisitView_VisitViewVisitID",
                table: "Dentists");

            migrationBuilder.DropForeignKey(
                name: "FK_Patients_VisitView_VisitViewVisitID",
                table: "Patients");

            migrationBuilder.DropIndex(
                name: "IX_Patients_VisitViewVisitID",
                table: "Patients");

            migrationBuilder.DropIndex(
                name: "IX_Dentists_VisitViewVisitID",
                table: "Dentists");

            migrationBuilder.DropColumn(
                name: "VisitViewVisitID",
                table: "Patients");

            migrationBuilder.DropColumn(
                name: "VisitViewVisitID",
                table: "Dentists");

            migrationBuilder.AddColumn<int>(
                name: "VisitViewVisitID1",
                table: "Services",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 1,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 2,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 3,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 4,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 5,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 6,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 7,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 8,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 9,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 10,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 11,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 12,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 13,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 14,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 15,
                column: "VisitViewVisitID1",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_Services_VisitViewVisitID1",
                table: "Services",
                column: "VisitViewVisitID1");

            migrationBuilder.AddForeignKey(
                name: "FK_Services_VisitView_VisitViewVisitID1",
                table: "Services",
                column: "VisitViewVisitID1",
                principalTable: "VisitView",
                principalColumn: "VisitID");
        }
    }
}
