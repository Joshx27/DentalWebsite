﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class AddColumnsToServiceTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "VisitID",
                table: "Services",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 1,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 2,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 3,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 4,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 5,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 6,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 7,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 8,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 9,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 10,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 11,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 12,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 13,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 14,
                column: "VisitID",
                value: null);

            migrationBuilder.UpdateData(
                table: "Services",
                keyColumn: "ServiceID",
                keyValue: 15,
                column: "VisitID",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_Services_VisitID",
                table: "Services",
                column: "VisitID");

            migrationBuilder.AddForeignKey(
                name: "FK_Services_Visits_VisitID",
                table: "Services",
                column: "VisitID",
                principalTable: "Visits",
                principalColumn: "VisitID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Services_Visits_VisitID",
                table: "Services");

            migrationBuilder.DropIndex(
                name: "IX_Services_VisitID",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "VisitID",
                table: "Services");
        }
    }
}
