﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class appointmenttype : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AppointmentTypes",
                columns: new[] { "TypeID", "AppointmentName", "Description", "Duration" },
                values: new object[,]
                {
                    { 1, "Cosmetic Consultation - Adult", "Initial consultation with adult patient to discuss cosmetic dentistry options.", new TimeSpan(0, 0, 30, 0, 0) },
                    { 2, "Cosmetic Consultation - Child", "Initial consultation with child patient to discuss cosmetic dentistry options.", new TimeSpan(0, 0, 30, 0, 0) },
                    { 3, "Cosmetic Consultation - Teen", "Initial consultation with teen patient to discuss cosmetic dentistry options.", new TimeSpan(0, 0, 30, 0, 0) },
                    { 4, "Cosmetic Procedure - Adult", "Cosmetic dentistry procedure for adult patient.", new TimeSpan(0, 2, 0, 0, 0) },
                    { 5, "Cosmetic Procedure - Child", "Cosmetic dentistry procedure for child patient.", new TimeSpan(0, 2, 0, 0, 0) },
                    { 6, "Cosmetic Procedure - Teen", "Cosmetic dentistry procedure for teen patient.", new TimeSpan(0, 2, 0, 0, 0) },
                    { 7, "Endodontic Procedure - Adult", "Painless root canal therapy for adults.", new TimeSpan(0, 1, 30, 0, 0) },
                    { 8, "Endodontic Procedure - Child", "Painless root canal therapy for children.", new TimeSpan(0, 1, 30, 0, 0) },
                    { 9, "Endodontic Procedure - Teen", "Painless root canal therapy for teens.", new TimeSpan(0, 1, 30, 0, 0) },
                    { 10, "New Patient - Adult", "Meet new patient with general dental check-up including x-rays and teeth cleaning.", new TimeSpan(0, 0, 30, 0, 0) },
                    { 11, "New Patient - Child", "Meet new patient with general dental check-up including x-rays and teeth cleaning.", new TimeSpan(0, 0, 30, 0, 0) },
                    { 12, "New Patient - Teen", "Meet new patient with general dental check-up including x-rays and teeth cleaning.", new TimeSpan(0, 0, 30, 0, 0) },
                    { 13, "Periodontal Treatment - Adult", "Treatment (both preventative or restorative) for gum diseases.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 14, "Periodontal Treatment - Child", "Treatment (both preventative or restorative) for gum diseases.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 15, "Periodontal Treatment - Teen", "Treatment (both preventative or restorative) for gum diseases.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 16, "Preventative Care - Adult", "General preventative care for an adult patient. The appointment will include x-rays, teeth cleaning, and general oral hygiene advising.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 17, "Preventative Care - Child", "General preventative care for a child patient. The appointment will include x-rays, teeth cleaning, and general oral hygiene advising.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 18, "Preventative Care - Teen", "General preventative care for a teen patient. The appointment will include x-rays, teeth cleaning, and general oral hygiene advising.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 19, "Prosthodontic Care - Adult", "Restoration and/or replacement of missing or damaged teeth for adults.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 20, "Prosthodontic Care - Child", "Restoration and/or replacement of missing or damaged teeth for children.", new TimeSpan(0, 1, 0, 0, 0) },
                    { 21, "Prosthodontic Care - Teen", "Restoration and/or replacement of missing or damaged teeth for teens.", new TimeSpan(0, 1, 0, 0, 0) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "AppointmentTypes",
                keyColumn: "TypeID",
                keyValue: 21);
        }
    }
}
