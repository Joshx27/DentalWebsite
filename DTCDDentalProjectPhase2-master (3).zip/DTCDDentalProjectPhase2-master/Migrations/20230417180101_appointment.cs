﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DTCDDentalProject.Migrations
{
    /// <inheritdoc />
    public partial class appointment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Appointments_AppointmentTypes_AppointmentTypeTypeID",
                table: "Appointments");

            migrationBuilder.DropForeignKey(
                name: "FK_Appointments_Dentists_DentistID",
                table: "Appointments");

            migrationBuilder.DropForeignKey(
                name: "FK_Appointments_Patients_PatientID",
                table: "Appointments");

            migrationBuilder.DropIndex(
                name: "IX_Appointments_AppointmentTypeTypeID",
                table: "Appointments");

            migrationBuilder.DropColumn(
                name: "AppointmentTypeTypeID",
                table: "Appointments");

            migrationBuilder.RenameColumn(
                name: "TypeID",
                table: "AppointmentTypes",
                newName: "AppointmentTypeID");

            migrationBuilder.RenameColumn(
                name: "TypeID",
                table: "Appointments",
                newName: "AppointmentTypeID");

            migrationBuilder.InsertData(
                table: "Appointments",
                columns: new[] { "AppointmentID", "AppointmentDate", "AppointmentTypeID", "DentistID", "PatientID", "StartTime" },
                values: new object[,]
                {
                    { 1, new DateTime(2023, 3, 27, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, 1, 1, new DateTime(2023, 3, 27, 10, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2023, 3, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), 10, 2, 7, new DateTime(2023, 3, 31, 10, 30, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2023, 3, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), 10, 3, 8, new DateTime(2023, 3, 31, 10, 30, 0, 0, DateTimeKind.Unspecified) },
                    { 4, new DateTime(2023, 3, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), 11, 2, 9, new DateTime(2023, 3, 31, 11, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2023, 3, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), 11, 3, 10, new DateTime(2023, 3, 31, 11, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 6, new DateTime(2023, 4, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), 4, 1, 1, new DateTime(2023, 4, 8, 11, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 7, new DateTime(2023, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 16, 2, 13, new DateTime(2023, 4, 1, 13, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 8, new DateTime(2023, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 16, 3, 12, new DateTime(2023, 4, 1, 15, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 9, new DateTime(2023, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), 16, 3, 15, new DateTime(2023, 4, 2, 9, 30, 0, 0, DateTimeKind.Unspecified) },
                    { 10, new DateTime(2023, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), 16, 1, 2, new DateTime(2023, 4, 3, 9, 30, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Appointments_AppointmentTypeID",
                table: "Appointments",
                column: "AppointmentTypeID");

            migrationBuilder.AddForeignKey(
                name: "FK_Appointments_AppointmentTypes_AppointmentTypeID",
                table: "Appointments",
                column: "AppointmentTypeID",
                principalTable: "AppointmentTypes",
                principalColumn: "AppointmentTypeID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Appointments_Dentists_DentistID",
                table: "Appointments",
                column: "DentistID",
                principalTable: "Dentists",
                principalColumn: "DentistID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Appointments_Patients_PatientID",
                table: "Appointments",
                column: "PatientID",
                principalTable: "Patients",
                principalColumn: "PatientID",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Appointments_AppointmentTypes_AppointmentTypeID",
                table: "Appointments");

            migrationBuilder.DropForeignKey(
                name: "FK_Appointments_Dentists_DentistID",
                table: "Appointments");

            migrationBuilder.DropForeignKey(
                name: "FK_Appointments_Patients_PatientID",
                table: "Appointments");

            migrationBuilder.DropIndex(
                name: "IX_Appointments_AppointmentTypeID",
                table: "Appointments");

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentID",
                keyValue: 10);

            migrationBuilder.RenameColumn(
                name: "AppointmentTypeID",
                table: "AppointmentTypes",
                newName: "TypeID");

            migrationBuilder.RenameColumn(
                name: "AppointmentTypeID",
                table: "Appointments",
                newName: "TypeID");

            migrationBuilder.AddColumn<int>(
                name: "AppointmentTypeTypeID",
                table: "Appointments",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Appointments_AppointmentTypeTypeID",
                table: "Appointments",
                column: "AppointmentTypeTypeID");

            migrationBuilder.AddForeignKey(
                name: "FK_Appointments_AppointmentTypes_AppointmentTypeTypeID",
                table: "Appointments",
                column: "AppointmentTypeTypeID",
                principalTable: "AppointmentTypes",
                principalColumn: "TypeID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Appointments_Dentists_DentistID",
                table: "Appointments",
                column: "DentistID",
                principalTable: "Dentists",
                principalColumn: "DentistID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Appointments_Patients_PatientID",
                table: "Appointments",
                column: "PatientID",
                principalTable: "Patients",
                principalColumn: "PatientID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
