﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;

namespace DTCDDentalProject.Models
{
    public class Patient
    {
        //Primary Key
        [Key]
        public int PatientID { get; set; }

        [Required(ErrorMessage = "Please enter a first name.")]
        public string PatientFirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a last name.")]
        public string PatientLastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a street address.")]
        public string PatientStreetAddress { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a city.")]
        public string PatientCity { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a state.")]
        public string PatientState { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a zip code.")]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Zip code must be in 5-digit or 9-digit format (e.g., 12345 or 12345-6789).")]
        public string PatientZip { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a phone number.")]
        [RegularExpression(@"^((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}$",
            ErrorMessage = "Phone number must be in (999) 999-9999 format.")]
        public string PatientPhone { get; set; } = string.Empty;
        public string? PatientEmail { get; set; }

        [Required(ErrorMessage = "Please enter a social security number.")]
        public long PatientSSN { get; set; }

        [Required(ErrorMessage = "Please enter a patient date of birth.")]
        public DateTime PatientDOB { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Is the patient a minor?")]
        public Boolean PatientMinor { get; set; }

        // Foreign Key
        //[Required(ErrorMessage = "Head of Household ID is required")]
        public int PatientHOHID { get; set; }

        //Navigation Key
        public Patient? PatientHOH { get; set; }

        public ICollection<Appointment>? appointments { get; set; }

        public ICollection<Visit>? visit { get; set; }

        public string PatientFullName => PatientFirstName + " " + PatientLastName;   // read-only property
    }
}
