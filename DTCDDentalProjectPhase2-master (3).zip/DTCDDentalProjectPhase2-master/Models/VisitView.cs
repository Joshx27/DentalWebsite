﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;

namespace DTCDDentalProject.Models
{
    /// <summary>
    /// Represents the view model for creating or editing a visit.
    /// </summary>
    public class VisitView
    {
        [Key]
        public int VisitID { get; set; } // the ID of the visit

        public Visit Visit { get; set; } = null!; // the visit associated with the view model

        public List<Dentist> Dentists { get; set; } = null!; // the list of available dentists

        public int DentistID { get; set; } // the ID of the selected dentist for the visit

        public List<Patient> Patients { get; set; } = null!; // the list of available patients

        public int PatientID { get; set; } // the ID of the selected patient for the visit

        public decimal TotalCost { get; set; } // the total cost of the services selected for the visit

        public List<Service> VisitCart { get; set; } = new List<Service>(); // the list of services selected for the visit
    }
}
