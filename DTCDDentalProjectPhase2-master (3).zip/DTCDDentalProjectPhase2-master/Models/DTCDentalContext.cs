﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;

namespace DTCDDentalProject.Models
{
    public class DTCDentalContext : DbContext
    {
        public DTCDentalContext(DbContextOptions<DTCDentalContext> options)
            : base(options)
        { }

        public DbSet<Patient> Patients { get; set; } = null!;
        public DbSet<Service> Services { get; set; } = null!;
        public DbSet<Dentist> Dentists { get; set; } = null!;
        public DbSet<AppointmentType> AppointmentTypes { get; set; } = null!;
        public DbSet<Appointment> Appointments { get; set; } = null!;
        public DbSet<Visit> Visits { get; set; } = null!;
        public DbSet<VisitView> VisitView { get; set; } = null!;
        public DbSet<CompletedService> CompletedServices { get; set; } = null!;


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //set refernetial integrity constraint for foreign key Patient HOH in Patient class
            modelBuilder.Entity<Patient>()
                .HasOne(x => x.PatientHOH)
                .WithMany()
                .HasForeignKey(x => x.PatientHOHID)
                .OnDelete(DeleteBehavior.Restrict);

            //seed data for Patient
            modelBuilder.Entity<Patient>().HasData(
                new Patient
                {
                    PatientID = 1,
                    PatientFirstName = "Daniel",
                    PatientLastName = "Ortiz",
                    PatientStreetAddress = "Way Over Dr.",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80113",
                    PatientPhone = "713-732-8964",
                    PatientEmail = "",
                    PatientSSN = 217569823,
                    PatientDOB = DateTime.Parse("2001-10-09"),
                    PatientMinor = false,
                    PatientHOHID = 1

                },
                new Patient
                {
                    PatientID = 2,
                    PatientFirstName = "Emily",
                    PatientLastName = "Garcia",
                    PatientStreetAddress = "4525 S Broadway",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80113",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 478681095,
                    PatientDOB = DateTime.Parse("1985-06-12"),
                    PatientMinor = false,
                    PatientHOHID = 2
                },
                new Patient
                {
                    PatientID = 3,
                    PatientFirstName = "Ryan",
                    PatientLastName = "Lee",
                    PatientStreetAddress = "4650 S. Yosemite St.",
                    PatientCity = "Denver",
                    PatientState = "CO",
                    PatientZip = "80237",
                    PatientPhone = "720-555-1212",
                    PatientEmail = "",
                    PatientSSN = 623945278,
                    PatientDOB = DateTime.Parse("1990-03-01"),
                    PatientMinor = false,
                    PatientHOHID = 3
                },
                new Patient
                {
                    PatientID = 4,
                    PatientFirstName = "Avery",
                    PatientLastName = "Nguyen",
                    PatientStreetAddress = "3595 S Pearl St",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80113",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 385317906,
                    PatientDOB = DateTime.Parse("1978-11-28"),
                    PatientMinor = false,
                    PatientHOHID = 4
                },
                new Patient
                {
                    PatientID = 5,
                    PatientFirstName = "Olivia",
                    PatientLastName = "Wilson",
                    PatientStreetAddress = "7315 E Belleview Ave",
                    PatientCity = "Greenwood Village",
                    PatientState = "CO",
                    PatientZip = "80111",
                    PatientPhone = "720-555-1212",
                    PatientEmail = "",
                    PatientSSN = 719468213,
                    PatientDOB = DateTime.Parse("2006-01-03"),
                    PatientMinor = true,
                    PatientHOHID = 3
                },
                new Patient
                {
                    PatientID = 6,
                    PatientFirstName = "Blake",
                    PatientLastName = "Hernandez",
                    PatientStreetAddress = "88 Inverness Cir E",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80112",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 242693150,
                    PatientDOB = DateTime.Parse("1996-08-22"),
                    PatientMinor = false,
                    PatientHOHID = 6
                },
                new Patient
                {
                    PatientID = 7,
                    PatientFirstName = "Isabella",
                    PatientLastName = "Martinez",
                    PatientStreetAddress = "3500 S. Logan St.",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80113",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 583124286,
                    PatientDOB = DateTime.Parse("1975-04-22"),
                    PatientMinor = false,
                    PatientHOHID = 7
                },
                new Patient
                {
                    PatientID = 8,
                    PatientFirstName = "Mason",
                    PatientLastName = "Gonzalez",
                    PatientStreetAddress = "3475 S University Blvd",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80113",
                    PatientPhone = "720-555-1212",
                    PatientEmail = "",
                    PatientSSN = 934772608,
                    PatientDOB = DateTime.Parse("1982-09-13"),
                    PatientMinor = false,
                    PatientHOHID = 7
                },
                new Patient
                {
                    PatientID = 9,
                    PatientFirstName = "Sophia",
                    PatientLastName = "Rodriguez",
                    PatientStreetAddress = "7447 E Berry Ave",
                    PatientCity = "Greenwood Village",
                    PatientState = "CO",
                    PatientZip = "80111",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 156538907,
                    PatientDOB = DateTime.Parse("2011-02-01"),
                    PatientMinor = true,
                    PatientHOHID = 7
                },
                new Patient
                {
                    PatientID = 10,
                    PatientFirstName = "Aiden",
                    PatientLastName = "Chavez",
                    PatientStreetAddress = "7395 E Peakview Ave",
                    PatientCity = "Centennial",
                    PatientState = "CO",
                    PatientZip = "80111",
                    PatientPhone = "720-555-1212",
                    PatientEmail = "",
                    PatientSSN = 341284689,
                    PatientDOB = DateTime.Parse("2004-05-15"),
                    PatientMinor = true,
                    PatientHOHID = 7
                },
                new Patient
                {
                    PatientID = 11,
                    PatientFirstName = "Aria",
                    PatientLastName = "Sanchez",
                    PatientStreetAddress = "10125 E Peakview Ave",
                    PatientCity = "Englewood",
                    PatientState = "CO",
                    PatientZip = "80111",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 806629351,
                    PatientDOB = DateTime.Parse("1999-11-10"),
                    PatientMinor = false,
                    PatientHOHID = 11
                },
                new Patient
                {
                    PatientID = 12,
                    PatientFirstName = "Oliver",
                    PatientLastName = "Flores",
                    PatientStreetAddress = "6500 E Hampden Ave",
                    PatientCity = "Denver",
                    PatientState = "CO",
                    PatientZip = "80224",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 575371032,
                    PatientDOB = DateTime.Parse("1988-06-18"),
                    PatientMinor = false,
                    PatientHOHID = 12
                },
                new Patient
                {
                    PatientID = 13,
                    PatientFirstName = "Emma",
                    PatientLastName = "Garcia",
                    PatientStreetAddress = "14200 E Alameda Ave",
                    PatientCity = "Aurora",
                    PatientState = "CO",
                    PatientZip = "80012",
                    PatientPhone = "720-555-1212",
                    PatientEmail = "",
                    PatientSSN = 989816025,
                    PatientDOB = DateTime.Parse("1991-09-25"),
                    PatientMinor = false,
                    PatientHOHID = 13
                },
                new Patient
                {
                    PatientID = 14,
                    PatientFirstName = "Noah",
                    PatientLastName = "Hernandez",
                    PatientStreetAddress = "2990 S Peoria St",
                    PatientCity = "Aurora",
                    PatientState = "CO",
                    PatientZip = "80014",
                    PatientPhone = "303-555-1212",
                    PatientEmail = "",
                    PatientSSN = 431247769,
                    PatientDOB = DateTime.Parse("1979-11-30"),
                    PatientMinor = false,
                    PatientHOHID = 14
                },
                new Patient
                {
                    PatientID = 15,
                    PatientFirstName = "Avery",
                    PatientLastName = "Lopez",
                    PatientStreetAddress = "7150 Leetsdale Dr",
                    PatientCity = "Denver",
                    PatientState = "CO",
                    PatientZip = "80224",
                    PatientPhone = "720-555-1212",
                    PatientEmail = "",
                    PatientSSN = 703503241,
                    PatientDOB = DateTime.Parse("1963-08-07"),
                    PatientMinor = false,
                    PatientHOHID = 15
                }
            );

            //seed data for Service
            modelBuilder.Entity<Service>().HasData(
                new Service { ServiceID = 1, ServiceDescription = "X-Ray", ServiceCost = 250 },
                new Service { ServiceID = 2, ServiceDescription = "Drill Cavity", ServiceCost = 350 },
                new Service { ServiceID = 3, ServiceDescription = "Crown", ServiceCost = 750 },
                new Service { ServiceID = 4, ServiceDescription = "Fill Cavity", ServiceCost = 250 },
                new Service { ServiceID = 5, ServiceDescription = "Extract Tooth", ServiceCost = 500 },
                new Service { ServiceID = 6, ServiceDescription = "Root Canal", ServiceCost = 1500 },
                new Service { ServiceID = 7, ServiceDescription = "Tooth Whitening", ServiceCost = 350 },
                new Service { ServiceID = 8, ServiceDescription = "Dental Implant", ServiceCost = 2500 },
                new Service { ServiceID = 9, ServiceDescription = "Dentures", ServiceCost = 4500 },
                new Service { ServiceID = 10, ServiceDescription = "Anesthetic", ServiceCost = 250 },
                new Service { ServiceID = 11, ServiceDescription = "Cleaning", ServiceCost = 150 },
                new Service { ServiceID = 12, ServiceDescription = "Pediatric Dental Counseling", ServiceCost = 350 },
                new Service { ServiceID = 13, ServiceDescription = "Dental Exam", ServiceCost = 500 },
                new Service { ServiceID = 14, ServiceDescription = "Dental Screening", ServiceCost = 250 },
                new Service { ServiceID = 15, ServiceDescription = "Flouride Treatment", ServiceCost = 275 }
            );


            //seed data for Dentist
            modelBuilder.Entity<Dentist>().HasData(
                 new Dentist
                 {
                     DentistID = 1,
                     DentistFirstName = "Ariana",
                     DentistLastName = "Grande",
                     HireDate = DateTime.Parse("2023-04-03"),
                 },
                 new Dentist
                 {
                     DentistID = 2,
                     DentistFirstName = "Emma",
                     DentistLastName = "Watson",
                     HireDate = DateTime.Parse("2022-07-22"),
                 },
                 new Dentist
                 {
                     DentistID = 3,
                     DentistFirstName = "Daniel",
                     DentistLastName = "Radcliffe",
                     HireDate = DateTime.Parse("2022-05-12"),
                 },
                 new Dentist
                 {
                     DentistID = 4,
                     DentistFirstName = "Jennifer",
                     DentistLastName = "Lawrence",
                     HireDate = DateTime.Parse("2022-10-05"),
                 },
                 new Dentist
                 {
                     DentistID = 5,
                     DentistFirstName = "Tom",
                     DentistLastName = "Hiddleston",
                     HireDate = DateTime.Parse("2023-01-15"),
                 }
             );


            //seed data for Appointment Type
            modelBuilder.Entity<AppointmentType>().HasData(
                        new AppointmentType
                        {
                            AppointmentTypeID = 1,
                            AppointmentName = "Cosmetic Consultation - Adult",
                            Description = "Initial consultation with adult patient to discuss cosmetic dentistry options.",
                            Duration = TimeSpan.FromMinutes(30)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 2,
                            AppointmentName = "Cosmetic Consultation - Child",
                            Description = "Initial consultation with child patient to discuss cosmetic dentistry options.",
                            Duration = TimeSpan.FromMinutes(30)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 3,
                            AppointmentName = "Cosmetic Consultation - Teen",
                            Description = "Initial consultation with teen patient to discuss cosmetic dentistry options.",
                            Duration = TimeSpan.FromMinutes(30)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 4,
                            AppointmentName = "Cosmetic Procedure - Adult",
                            Description = "Cosmetic dentistry procedure for adult patient.",
                            Duration = TimeSpan.FromMinutes(120)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 5,
                            AppointmentName = "Cosmetic Procedure - Child",
                            Description = "Cosmetic dentistry procedure for child patient.",
                            Duration = TimeSpan.FromMinutes(120)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 6,
                            AppointmentName = "Cosmetic Procedure - Teen",
                            Description = "Cosmetic dentistry procedure for teen patient.",
                            Duration = TimeSpan.FromMinutes(120)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 7,
                            AppointmentName = "Endodontic Procedure - Adult",
                            Description = "Painless root canal therapy for adults.",
                            Duration = TimeSpan.FromMinutes(90)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 8,
                            AppointmentName = "Endodontic Procedure - Child",
                            Description = "Painless root canal therapy for children.",
                            Duration = TimeSpan.FromMinutes(90)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 9,
                            AppointmentName = "Endodontic Procedure - Teen",
                            Description = "Painless root canal therapy for teens.",
                            Duration = TimeSpan.FromMinutes(90)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 10,
                            AppointmentName = "New Patient - Adult",
                            Description = "Meet new patient with general dental check-up including x-rays and teeth cleaning.",
                            Duration = TimeSpan.FromMinutes(30)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 11,
                            AppointmentName = "New Patient - Child",
                            Description = "Meet new patient with general dental check-up including x-rays and teeth cleaning.",
                            Duration = TimeSpan.FromMinutes(30)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 12,
                            AppointmentName = "New Patient - Teen",
                            Description = "Meet new patient with general dental check-up including x-rays and teeth cleaning.",
                            Duration = TimeSpan.FromMinutes(30)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 13,
                            AppointmentName = "Periodontal Treatment - Adult",
                            Description = "Treatment (both preventative or restorative) for gum diseases.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 14,
                            AppointmentName = "Periodontal Treatment - Child",
                            Description = "Treatment (both preventative or restorative) for gum diseases.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 15,
                            AppointmentName = "Periodontal Treatment - Teen",
                            Description = "Treatment (both preventative or restorative) for gum diseases.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 16,
                            AppointmentName = "Preventative Care - Adult",
                            Description = "General preventative care for an adult patient. The appointment will include x-rays, teeth cleaning, and general oral hygiene advising.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 17,
                            AppointmentName = "Preventative Care - Child",
                            Description = "General preventative care for a child patient. The appointment will include x-rays, teeth cleaning, and general oral hygiene advising.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 18,
                            AppointmentName = "Preventative Care - Teen",
                            Description = "General preventative care for a teen patient. The appointment will include x-rays, teeth cleaning, and general oral hygiene advising.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 19,
                            AppointmentName = "Prosthodontic Care - Adult",
                            Description = "Restoration and/or replacement of missing or damaged teeth for adults.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 20,
                            AppointmentName = "Prosthodontic Care - Child",
                            Description = "Restoration and/or replacement of missing or damaged teeth for children.",
                            Duration = TimeSpan.FromMinutes(60)
                        },
                        new AppointmentType
                        {
                            AppointmentTypeID = 21,
                            AppointmentName = "Prosthodontic Care - Teen",
                            Description = "Restoration and/or replacement of missing or damaged teeth for teens.",
                            Duration = TimeSpan.FromMinutes(60)
                        }
                    );


            //set refernetial integrity constraint for foreign keys Dentist, Patient, Type in Appointment class

            modelBuilder.Entity<Appointment>()
                       .HasOne(a => a.Dentist)
                       .WithMany(a => a.Appointments)
                       .HasForeignKey(a => a.DentistID)
                       .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Appointment>()
                        .HasOne(p => p.Patient)
                        .WithMany(a => a.appointments)
                        .HasForeignKey(P => P.PatientID)
                        .OnDelete(DeleteBehavior.Restrict);


            //seed data for Appointment
            modelBuilder.Entity<Appointment>().HasData(
                        new Appointment
                        {
                            AppointmentID = 1,
                            AppointmentDate = new DateTime(2023, 3, 27),
                            StartTime = new DateTime(2023, 3, 27, 10, 0, 0),
                            DentistID = 1,
                            AppointmentTypeID = 1,
                            PatientID = 1
                        },
                        new Appointment
                        {
                            AppointmentID = 2,
                            AppointmentDate = new DateTime(2023, 3, 31),
                            StartTime = new DateTime(2023, 3, 31, 10, 30, 0),
                            DentistID = 2,
                            AppointmentTypeID = 10,
                            PatientID = 7
                        },
                        new Appointment
                        {
                            AppointmentID = 3,
                            AppointmentDate = new DateTime(2023, 3, 31),
                            StartTime = new DateTime(2023, 3, 31, 10, 30, 0),
                            DentistID = 3,
                            AppointmentTypeID = 10,
                            PatientID = 8
                        },
                        new Appointment
                        {
                            AppointmentID = 4,
                            AppointmentDate = new DateTime(2023, 3, 31),
                            StartTime = new DateTime(2023, 3, 31, 11, 0, 0),
                            DentistID = 2,
                            AppointmentTypeID = 11,
                            PatientID = 9
                        },
                        new Appointment
                        {
                            AppointmentID = 5,
                            AppointmentDate = new DateTime(2023, 3, 31),
                            StartTime = new DateTime(2023, 3, 31, 11, 0, 0),
                            DentistID = 3,
                            AppointmentTypeID = 11,
                            PatientID = 10
                        },
                        new Appointment
                        {
                            AppointmentID = 6,
                            AppointmentDate = new DateTime(2023, 4, 8),
                            StartTime = new DateTime(2023, 4, 8, 11, 0, 0),
                            DentistID = 1,
                            AppointmentTypeID = 4,
                            PatientID = 1
                        },
                        new Appointment
                        {
                            AppointmentID = 7,
                            AppointmentDate = new DateTime(2023, 4, 1),
                            StartTime = new DateTime(2023, 4, 1, 13, 0, 0),
                            DentistID = 2,
                            AppointmentTypeID = 16,
                            PatientID = 13
                        },
                        new Appointment
                        {
                            AppointmentID = 8,
                            AppointmentDate = new DateTime(2023, 4, 1),
                            StartTime = new DateTime(2023, 4, 1, 15, 0, 0),
                            DentistID = 3,
                            AppointmentTypeID = 16,
                            PatientID = 12
                        },
                        new Appointment
                        {
                            AppointmentID = 9,
                            AppointmentDate = new DateTime(2023, 4, 2),
                            StartTime = new DateTime(2023, 4, 2, 9, 30, 0),
                            DentistID = 3,
                            AppointmentTypeID = 16,
                            PatientID = 15
                        },
                        new Appointment
                        {
                            AppointmentID = 10,
                            AppointmentDate = new DateTime(2023, 4, 3),
                            StartTime = new DateTime(2023, 4, 3, 9, 30, 0),
                            DentistID = 1,
                            AppointmentTypeID = 16,
                            PatientID = 2
                        }
                    );

            //set refernetial integrity constraint for foreign keys Dentist and Patient in Visit class
            modelBuilder.Entity<Visit>()
                         .HasOne(v => v.Dentist)
                         .WithMany(v => v.visit)
                         .HasForeignKey(v => v.DentistID)
                         .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Visit>()
                        .HasOne(v => v.Patient)
                        .WithMany(v => v.visit)
                        .HasForeignKey(v => v.PatientID)
                        .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<VisitView>()
                        .HasKey(v => v.VisitID);

            //seed data for Visit
            modelBuilder.Entity<Visit>().HasData(
                        new Visit
                        {
                            VisitID = 1,
                            DentistID = 1,
                            PatientID = 1,
                            VisitDate = new DateTime(2023, 3, 27),
                        },
                        new Visit
                        {
                            VisitID = 2,
                            DentistID = 2,
                            PatientID = 7,
                            VisitDate = new DateTime(2023, 3, 31),
                        },
                        new Visit
                        {
                            VisitID = 3,
                            DentistID = 3,
                            PatientID = 8,
                            VisitDate = new DateTime(2023, 3, 31),
                        },
                        new Visit
                        {
                            VisitID = 4,
                            DentistID = 2,
                            PatientID = 9,
                            VisitDate = new DateTime(2023, 3, 31),
                        },
                        new Visit
                        {
                            VisitID = 5,
                            DentistID = 3,
                            PatientID = 10,
                            VisitDate = new DateTime(2023, 3, 31),
                        },
                        new Visit
                        {
                            VisitID = 6,
                            DentistID = 1,
                            PatientID = 1,
                            VisitDate = new DateTime(2023, 4, 8),
                        },
                        new Visit
                        {
                            VisitID = 7,
                            DentistID = 2,
                            PatientID = 13,
                            VisitDate = new DateTime(2023, 4, 1),
                        },
                        new Visit
                        {
                            VisitID = 8,
                            DentistID = 3,
                            PatientID = 12,
                            VisitDate = new DateTime(2023, 4, 1),
                        },
                        new Visit
                        {
                            VisitID = 9,
                            DentistID = 3,
                            PatientID = 15,
                            VisitDate = new DateTime(2023, 4, 2),
                        },
                        new Visit
                        {
                            VisitID = 10,
                            DentistID = 1,
                            PatientID = 2,
                            VisitDate = new DateTime(2023, 4, 3),
                        }
                    );
        
        //set composite primary key for CompletedService
        modelBuilder.Entity<CompletedService>()
                    .HasKey(cs => new { cs.ServiceID, cs.VisitID
    });

                //seed data for CompletedService
                modelBuilder.Entity<CompletedService>().HasData(
                    new CompletedService
                    {
                        ServiceID = 1,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 2,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 2,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 3,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 3,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 4,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 4,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 5,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 5,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 6,
                        VisitID = 7
                    },
                    new CompletedService
                    {
                        ServiceID = 7,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 7,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 8,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 8,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 9,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 9,
                        VisitID = 11
                    },
                    new CompletedService
                    {
                        ServiceID = 10,
                        VisitID = 1
                    },
                    new CompletedService
                    {
                        ServiceID = 10,
                        VisitID = 11
                    }
                );
            }
        }
}
