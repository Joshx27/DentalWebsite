﻿using System.ComponentModel.DataAnnotations;

namespace DTCDDentalProject.Models
{
    public class Dentist
    {
        [Key]
        public int DentistID { get; set; } // Primary Key

        [Required(ErrorMessage = "Dentist first name is required")]
        public string DentistFirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Dentist last name is required")]
        public string DentistLastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Hire date is required")]
        public DateTime HireDate { get; set; }

        public ICollection<Appointment>? Appointments { get; set; }
        public ICollection<Visit>? visit { get; set; }
    }
}
