﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DTCDDentalProject.Models
{
    public class Visit
    {
        [Key]
        public int VisitID { get; set; } // Primary Key

        [Required(ErrorMessage = "The DentistID field is required.")]
        [ForeignKey("Dentist")]
        public int DentistID { get; set; } // Foreign Key
        public Dentist Dentist { get; set; } = null!; // Navigation property

        [Required(ErrorMessage = "The PatientID field is required.")]
        [ForeignKey("Patient")]
        public int PatientID { get; set; } // Foreign Key
        public Patient Patient { get; set; } = null!; // Navigation property

        [Required(ErrorMessage = "The VisitDate field is required.")]
        public DateTime VisitDate { get; set; }
    }
}
