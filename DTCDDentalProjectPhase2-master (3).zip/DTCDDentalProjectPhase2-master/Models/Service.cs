﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;

namespace DTCDDentalProject.Models
{
    public class Service
    {
        [Key]
        public int ServiceID { get; set; } // Primary Key

        [Required(ErrorMessage = "Service description is required")]
        public string ServiceDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Service cost is required")]
        [Range(0, double.MaxValue, ErrorMessage = "Service cost must be greater than or equal to 0")]
        public decimal ServiceCost { get; set; }
    }
}
