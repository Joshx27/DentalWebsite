﻿using System.ComponentModel.DataAnnotations;

namespace DTCDDentalProject.Models
{
    public class AppointmentType
    {
        //Primary Key
        [Key]
        public int AppointmentTypeID { get; set; }

        [Required(ErrorMessage = "Please enter an appointment name.")]
        public string AppointmentName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a description.")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a duration.")]
        public TimeSpan Duration { get; set; } = TimeSpan.FromMinutes(0);
    }
}
