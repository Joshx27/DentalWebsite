﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DTCDDentalProject.Models
{
    public class Appointment
    {
        // Primary Key
        [Key]
        public int AppointmentID { get; set; }

        [Required(ErrorMessage = "Appointment date is required")]
        public DateTime AppointmentDate { get; set; }

        [Required(ErrorMessage = "Start time is required")]
        public DateTime StartTime { get; set; }

        //Foreign Keys
        [ForeignKey("Dentist")]
        [Required(ErrorMessage = "Dentist ID is required")]
        public int DentistID { get; set; }
        [ValidateNever]
        public Dentist Dentist { get; set; } = null!;

        [ForeignKey("Patient")]
        [Required(ErrorMessage = "Patient ID is required")]
        public int PatientID { get; set; }

        [ForeignKey("Appointment Type")]
        [Required(ErrorMessage = "Appointment type ID is required")]
        public int AppointmentTypeID { get; set; }

        [Required(ErrorMessage = "AppointmentType is required")]
        [ValidateNever]
        public AppointmentType AppointmentType { get; set; } = null!;

        // Navigation Properties
        
        [ValidateNever]
        public Patient Patient { get; set; } = null!;
        
    }
}