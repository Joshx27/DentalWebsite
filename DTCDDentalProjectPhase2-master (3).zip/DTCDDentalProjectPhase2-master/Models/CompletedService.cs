﻿using Microsoft.EntityFrameworkCore;

namespace DTCDDentalProject.Models
{
    public class CompletedService
    {
       
        public int ServiceID { get; set; }
        public int VisitID { get; set; }

    }
}
